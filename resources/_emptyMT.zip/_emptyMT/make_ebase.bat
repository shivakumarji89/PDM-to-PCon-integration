@echo off
echo .
ebmkdb.exe mt.inp_descr test.ebase
echo test.ebase is made
echo .
echo .
echo .
echo .
pause
