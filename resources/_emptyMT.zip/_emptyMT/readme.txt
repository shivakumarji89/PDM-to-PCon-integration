Metatype Setup
--------------

- ensure that the "MT 1.x" metatype format and "Standard" metatype class is set (and exported) for the product line in REGORG

- copy ALL the files in this folder in to the corresponding hmx repository ("\hmx\[package]\1\" folder)

- edit the make_ebase.bat file (in the repo) and replace BOTH instances of "test.ebase" with "[package].ebase" - where [package] is the product name in lowercase (eg. "ruby.ebase")

- export the latest metatype data from PDM and choose "Yes" when asked whether or not to run the make_ebase.bat script

- note: go_texts.csv is not currently exported from PDM, but thus can be manually edited to add descriptions for the values (in each language), as required
